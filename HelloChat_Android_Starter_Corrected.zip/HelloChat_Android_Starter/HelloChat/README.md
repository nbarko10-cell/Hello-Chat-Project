# Hello Chat — Android starter

This is a native Android Studio starter built with Kotlin and Jetpack Compose.

## Open and run
1. Install Android Studio on a computer.
2. Open this folder (`HelloChat`) as a project.
3. Let Gradle sync finish.
4. Run the `app` configuration on an Android emulator or connected Android phone.

## Current scope
- UI prototype only; demo contact/user records are placeholders.
- No live account login, chat delivery, audio/video calling, AI API, or remote admin control is connected yet.
- Before public release, add a backend, authentication, access rules, secure storage, privacy notice, and tests.

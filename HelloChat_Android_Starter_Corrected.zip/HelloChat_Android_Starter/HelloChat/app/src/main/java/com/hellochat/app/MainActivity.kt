package com.hellochat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF100D19)
private val Panel = Color(0xFF1D172A)
private val Violet = Color(0xFF9A5BFF)
private val Muted = Color(0xFFB8ADC9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HelloChatApp() }
    }
}

@Composable
fun HelloChatApp() {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            background = Ink,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Muted) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Chat, null) }, label = { Text("Chats") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.People, null) }, label = { Text("Contacts") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.SmartToy, null) }, label = { Text("DragoAI") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profile") })
                }
            },
            floatingActionButton = {
                if (tab == 0 || tab == 1) {
                    FloatingActionButton(onClick = { }, containerColor = Violet, contentColor = Color.White) {
                        Icon(Icons.Default.Add, contentDescription = "New chat")
                    }
                }
            }
        ) { pad ->
            when (tab) {
                0 -> ChatsScreen(Modifier.padding(pad))
                1 -> ContactsScreen(Modifier.padding(pad))
                2 -> DragoScreen(Modifier.padding(pad))
                else -> ProfileScreen(Modifier.padding(pad))
            }
        }
    }
}

@Composable
fun DragonMark() {
    Box(
        modifier = Modifier.size(54.dp).background(
            Brush.linearGradient(listOf(Color(0xFF6C2BD9), Color(0xFF1D1232))),
            CircleShape
        ),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Default.FlashOn, contentDescription = "Hello Chat dragon-inspired mark",
            tint = Color(0xFFE6D3FF), modifier = Modifier.size(30.dp))
    }
}

@Composable
fun ChatsScreen(modifier: Modifier = Modifier) {
    val names = listOf("DragoAI", "Arko", "Study Group", "Ayon")
    val messages = listOf("Ask me anything — let's learn.", "Are you online?", "Tomorrow's plan?", "Sent a photo")
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            DragonMark()
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Hello Chat", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Your people, your space", color = Muted, fontSize = 13.sp)
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = {}) { Icon(Icons.Default.Search, "Search", tint = Color.White) }
        }
        Spacer(Modifier.height(22.dp))
        OutlinedTextField(
            value = "", onValueChange = {}, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search chats") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(18.dp), singleLine = true
        )
        Spacer(Modifier.height(18.dp))
        Text("RECENT CHATS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(names.indices.toList()) { i ->
                Row(
                    Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp))
                        .clickable { }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).background(Color(0xFF332348), CircleShape), contentAlignment = Alignment.Center) {
                        if (i == 0) Icon(Icons.Default.AutoAwesome, null, tint = Violet)
                        else Text(names[i].take(1), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(names[i], fontWeight = FontWeight.SemiBold)
                        Text(messages[i], color = Muted, fontSize = 13.sp, maxLines = 1)
                    }
                    if (i == 0) Text("AI", color = Violet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ContactsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Contacts", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Add friends with their 8-digit Hello ID", color = Muted)
        Spacer(Modifier.height(20.dp))
        var id by remember { mutableStateOf("") }
        OutlinedTextField(value = id, onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) id = it },
            modifier = Modifier.fillMaxWidth(), label = { Text("8-digit Hello ID") },
            leadingIcon = { Icon(Icons.Default.Tag, null) }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        Button(onClick = {}, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
            Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(8.dp)); Text("Find friend")
        }
        Spacer(Modifier.height(22.dp))
        Text("Your contact list will appear here after secure sign-in is connected.", color = Muted)
    }
}

@Composable
fun DragoScreen(modifier: Modifier = Modifier) {
    var prompt by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            DragonMark()
            Spacer(Modifier.width(12.dp))
            Column {
                Text("DragoAI", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Study, create, solve", color = Muted)
            }
        }
        Spacer(Modifier.height(22.dp))
        Box(Modifier.fillMaxWidth().weight(1f).background(Panel, RoundedCornerShape(22.dp)).padding(18.dp)) {
            Column {
                Text("Hey! I'm DragoAI 🐉", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("I can help with lessons, writing, ideas and everyday tasks. Connect an AI service to enable real answers.",
                    color = Muted)
                Spacer(Modifier.height(16.dp))
                Text("This starter screen is a UI demo; AI replies are not connected yet.", color = Violet, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = prompt, onValueChange = { prompt = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Message DragoAI...") },
                shape = RoundedCornerShape(18.dp), maxLines = 3)
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { prompt = "" }) {
                Icon(Icons.Default.Send, "Send", tint = Violet)
            }
        }
    }
}

@Composable
fun ProfileScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Your profile", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Box(Modifier.size(76.dp).background(Color(0xFF332348), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, tint = Violet, modifier = Modifier.size(42.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text("Guest user", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text("Hello ID: — — — — — — — —", color = Muted)
        Spacer(Modifier.height(20.dp))
        Text("Sign-in providers, profile sync and permanent ID generation will be added in the backend phase.",
            color = Muted)
    }
}

package com.hellochat.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF100D19)
private val Panel = Color(0xFF1D172A)
private val Violet = Color(0xFF9A5BFF)
private val Muted = Color(0xFFB8ADC9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AdminApp() }
    }
}

@Composable
fun AdminApp() {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Ink, surface = Panel)) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("Overview") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.People, null) }, label = { Text("Users") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Flag, null) }, label = { Text("Reports") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            }
        ) { pad ->
            when (tab) {
                0 -> Overview(Modifier.padding(pad))
                1 -> Users(Modifier.padding(pad))
                2 -> Reports(Modifier.padding(pad))
                else -> Settings(Modifier.padding(pad))
            }
        }
    }
}

@Composable
fun AdminHeader(subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(50.dp).background(Brush.linearGradient(listOf(Violet, Color(0xFF2C1749))), CircleShape),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Shield, null, tint = Color.White, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Hello Chat Admin", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(subtitle, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
fun Overview(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        AdminHeader("Secure administration console")
        Spacer(Modifier.height(22.dp))
        Text("OVERVIEW", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Users", "—", Modifier.weight(1f), "Registered accounts")
            StatCard("Reports", "—", Modifier.weight(1f), "Needs review")
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Messages", "—", Modifier.weight(1f), "Metadata only")
            StatCard("Status", "Demo", Modifier.weight(1f), "Backend not connected")
        }
        Spacer(Modifier.height(20.dp))
        Text("Admin activity", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(8.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp)) {
                Text("No live events yet", fontWeight = FontWeight.SemiBold, color = Color.White)
                Spacer(Modifier.height(4.dp))
                Text("Connect authenticated admin APIs to show audit events and reported content.",
                    color = Muted)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Privacy note: access to message content should be limited to clearly disclosed, authorized moderation workflows.",
            color = Violet, fontSize = 13.sp)
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier, detail: String) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 13.sp)
            Text(value, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun Users(modifier: Modifier = Modifier) {
    val names = listOf("Demo User 01", "Demo User 02", "Demo User 03")
    Column(modifier.fillMaxSize().padding(20.dp)) {
        AdminHeader("User management")
        Spacer(Modifier.height(20.dp))
        Text("Demo data only — real user records require admin authentication.", color = Muted)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(names) { name ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountCircle, null, tint = Violet, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("ID: not assigned", color = Muted, fontSize = 12.sp)
                    }
                    Text("Demo", color = Violet, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun Reports(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        AdminHeader("Safety and report review")
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(18.dp)) {
                Icon(Icons.Default.Flag, null, tint = Violet, modifier = Modifier.size(32.dp))
                Spacer(Modifier.height(10.dp))
                Text("No reports loaded", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Reports submitted by users will appear here after the secure backend is connected. Review access should be logged.",
                    color = Muted)
            }
        }
    }
}

@Composable
fun Settings(modifier: Modifier = Modifier) {
    var announcements by remember { mutableStateOf(true) }
    var maintenance by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(20.dp)) {
        AdminHeader("App settings")
        Spacer(Modifier.height(22.dp))
        Text("DEMO CONTROLS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Allow announcements", color = Color.White)
                        Text("Enable admin-to-user notices", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = announcements, onCheckedChange = { announcements = it })
                }
                Divider(color = Color(0xFF3B304D))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Maintenance mode", color = Color.White)
                        Text("Demo toggle only; not applied to live users", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = maintenance, onCheckedChange = { maintenance = it })
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("These switches are local demo state. Live changes need role-based server APIs and an audit log.",
            color = Muted, fontSize = 13.sp)
    }
}

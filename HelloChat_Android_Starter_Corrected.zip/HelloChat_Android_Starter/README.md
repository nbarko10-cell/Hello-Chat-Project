# Hello Chat Android Starter Pack

This ZIP contains two separate Android Studio projects:
- `HelloChat/` — user-facing chat UI prototype
- `HelloChatAdmin/` — admin dashboard UI prototype

## Important
These are the first UI/code scaffolds, not production-ready apps or installable APKs. They need Android Studio to build, and a backend is still needed for real sign-in, permanent 8-digit IDs, online messaging, audio/video calls, DragoAI responses, report handling, and admin announcements.

The admin app is designed around disclosed, authorized moderation and audit workflows; it is not a hidden system for secretly reading every user's private conversation.
